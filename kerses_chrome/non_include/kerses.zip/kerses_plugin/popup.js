/*
TODO: Make the paper button do a query on the current page
      Add useful info on hover over info button
      Keep track of number of articles queried and add it to running total
      Get that information for the popup
*/
